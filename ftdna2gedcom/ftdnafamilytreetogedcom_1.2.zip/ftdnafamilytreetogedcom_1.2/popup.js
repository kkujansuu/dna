KangoAPI.onReady(function() {
    $('#all').click(function(event) {
        kango.storage.setItem("scope","all");
    });
    $('#ancestors').click(function(event) {
        kango.storage.setItem("scope","ancestors");
    });
});
